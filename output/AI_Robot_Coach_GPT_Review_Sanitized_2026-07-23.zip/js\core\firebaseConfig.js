export const firebaseConfig = {
  apiKey: "FIREBASE_API_KEY_REMOVED",
  authDomain: "firebase-project-id-removed.firebaseapp.com",
  projectId: "firebase-project-id-removed",
  storageBucket: "firebase-project-id-removed.firebasestorage.app",
  messagingSenderId: "000000000000",
  appId: "FIREBASE_APP_ID_REMOVED"
};

export function hasFirebaseConfig() {
  return Boolean(
    firebaseConfig.apiKey
    && firebaseConfig.authDomain
    && firebaseConfig.projectId
    && firebaseConfig.appId
  );
}

export const firebaseConfigGuide = [
  "Firebase 콘솔에서 웹 앱 설정 값을 복사해 이 파일에 붙여넣으세요.",
  "현재 단계에서는 Firebase Storage를 사용하지 않습니다.",
  "설정 값이 비어 있으면 앱은 localStorage fallback으로 동작합니다."
];
